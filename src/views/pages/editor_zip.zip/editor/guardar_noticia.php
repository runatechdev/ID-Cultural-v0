<?php
header('Content-Type: application/json');
$data = json_decode(file_get_contents("php://input"), true);

$titulo = $data['titulo'] ?? '';
$contenido = $data['contenido'] ?? '';
$autor = $data['autor'] ?? 'Editor';

if ($titulo && $contenido) {
    $conn = new PDO("sqlite:" . __DIR__ . "/../db/database.sqlite");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $conn->prepare("INSERT INTO noticias (titulo, contenido, autor) VALUES (?, ?, ?)");
    $stmt->execute([$titulo, $contenido, $autor]);

    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Datos incompletos']);
}
